import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class sketch_180223a extends PApplet {

class Enemy{
  float x, y;
  float speedX, speedY;
  float r = 0, g = 255, b = 0;
}

class Character{
  float x = 100, y = 100;
  float sizeX = 15, sizeY = 15;
}
  

class Gold{
  float x = random(0, width), y = random(0, width);
}

int score = 0;
int numGold = 0;
int numLives = 1;
int numEnemy = 20;
float fsrf = 12.5f;
float fsrffsrf = 17.5f;
float maxSpeed = 2;
float minSpeed = 0.25f;
float charSpeedX = 3;
float charSpeedY = 3;
float chance = 10;

Enemy[] enemies = new Enemy[1000];
Character character = new Character();

public void setup() {
  
  
  character.x = width / 2;
  character.y = height / 2;
  
  int i = 0;
  while (i < enemies.length) {
    Enemy newEnemy = new Enemy();
    if (i <= 19){
      newEnemy.x = 1;
      newEnemy.y = 1;
      newEnemy.speedX = random(.1f, 2);
      newEnemy.speedY = random(.1f, 2);
    }
    else {
      newEnemy.x = -100;
      newEnemy.y = -100;
      newEnemy.speedX = random(.1f, 2);
      newEnemy.speedY = random(.1f, 2);
    }
    
    enemies[i] = newEnemy;
    i += 1;
  }
}

  Gold gold = new Gold();

public void draw() {
  background(255, 255, 255);
   if (numLives > 0){
     score += 1;
  if (key == 'p'){
    numLives += 100;
  }
  fill(150, 150, 0);
  ellipse(gold.x, gold.y, 20, 20);
  if (dist(character.x, character.y, gold.x, gold.y) < fsrffsrf){
    numGold += 1;
    gold.x = random(0, width);
    gold.y = random(0, height);
    fsrffsrf = (character.sizeX/2) + 10;
  }
  if (numGold >= 5){
    numGold -= 5;
    numLives += 1;
  }
  
  int i = 0;
  while (i < enemies.length) {
    
    Enemy currentEnemy = enemies[i];
    
      if ((int)random(0, 10) == 1){
        if (chance > 1){
      chance -= 1;
        }
    }
    if ((int)random(0, chance) == 1){
        if (currentEnemy.x > character.x && currentEnemy.speedX > 0){
          currentEnemy.speedX *= -1;
        }
        if (currentEnemy.y > character.y && currentEnemy.speedY > 0){
          currentEnemy.speedY *= -1;
        }
        if (currentEnemy.x < character.x && currentEnemy.speedX < 0){
          currentEnemy.speedX *= -1;
        }
        if (currentEnemy.y < character.y && currentEnemy.speedY < 0){
          currentEnemy.speedY *= -1;
        }
      }
    if ((int)random(0, 40) == 1){
      if ((int)random(0, 25) == 1){
        currentEnemy.speedX = random(minSpeed, maxSpeed);
        currentEnemy.speedY = random(minSpeed, maxSpeed);
      }
      if ((int)random(0, 100) == 1){
        minSpeed += random(0.00005f, 0.0001f);
        maxSpeed += random(0.00005f, 0.0001f);
      }
      if ((int)random(0, 5000) == 1){
        currentEnemy.x = random(0, width);
        currentEnemy.y = random(0, height);
      }
      if ((int)random(0, 100) == 1){
        charSpeedX += random(0.00005f, 0.0001f);
        charSpeedY += random(0.00005f, 0.0001f);
      }
    }
    
    if (dist(character.x, character.y, currentEnemy.x, currentEnemy.y)<fsrf){
      numLives -= 1;
      character.x = random(0, width);
      character.y = random(0, height);
      fsrf = (character.sizeX/2) + 5;
    }
    
    if (mousePressed){
      currentEnemy.x = mouseX;
      currentEnemy.y = mouseY;
      numEnemy += 1;
    }
    
    fill(currentEnemy.r, currentEnemy.g, currentEnemy.b);
    ellipse(currentEnemy.x, currentEnemy.y, 10, 10);
    
    currentEnemy.x += currentEnemy.speedX;
    currentEnemy.y += currentEnemy.speedY;
    
    if (currentEnemy.x > width || currentEnemy.x < 0) {
       currentEnemy.speedX *= -1;
    }
    
    if (currentEnemy.y > height || currentEnemy.y < 0) {
       currentEnemy.speedY *= -1;
    }
     
     i += 1;
  }
  
  fill(255, 0, 0);
  
  ellipse(character.x, character.y, character.sizeX, character.sizeY);
  
  if (character.x > width || character.x < 0){
    character.x = width-character.x;
  }
  if (character.y > height || character.y < 0){
    character.y = height-character.y;
  }
  
  if (keyPressed) {
    // This code
    
    if (key == 'w') {
      character.y -= charSpeedX;
    }
    if (key == 's') {
      character.y += charSpeedX;
    }
    if (key == 'a') {
      character.x -= charSpeedY;
    }
    if (key == 'd') {
      character.x += charSpeedY;
    }
  }
  
  fill(0, 0, 255);
  text(str(numGold) + " gold! " + str(numLives) + " lives left! Your score is: " + str(score), width/4, height/2);
  

}
else {
  text("Game Over! TIP: Try to get the gold! Press your mouse to restart. Your score was: " + str(score), width/4, height/2);
  if (mousePressed){
    numLives += 1;
  score = 0;
  numGold = 0;
  numLives = 1;
  numEnemy = 20;
  fsrf = 12.5f;
  fsrffsrf = 17.5f;
  maxSpeed = 2;
  minSpeed = 0.5f;
  charSpeedX = 3;
  charSpeedY = 3;
  chance = 20;  
  character.x = width / 2;
  character.y = height / 2;
  
  int i = 0;
  while (i < enemies.length) {
    Enemy newEnemy = new Enemy();
    if (i <= 19){
      newEnemy.x = 1;
      newEnemy.y = 1;
      newEnemy.speedX = random(.1f, 2);
      newEnemy.speedY = random(.1f, 2);
    }
    else {
      newEnemy.x = -100;
      newEnemy.y = -100;
      newEnemy.speedX = random(.1f, 2);
      newEnemy.speedY = random(.1f, 2);
    }
    
    enemies[i] = newEnemy;
    i += 1;
  }
  delay(500);
  }
}
}
  public void settings() {  size(1000, 700); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "sketch_180223a" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
